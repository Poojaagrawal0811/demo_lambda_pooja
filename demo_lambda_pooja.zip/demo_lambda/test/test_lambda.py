# import json
# import pytest
# # from src.demo_lambda import lambda_handler
#
# @pytest.fixture()
# def fixture_event():
#     return{
#         "body":{"first_name":"pooja","last_name":"agrawal","email":"poojaagrawal0811@gmail.com","passwword":"4321"}
#
#     }
#
# def test_lambda_handler():
#
#     try:
#         response = lambda_handler({'Records': []}, {})
#     except Exception as e:
#         print(e)
#
#     assert True == True
#     assert "successfully"
# class TestRegistrationAPI:
#     def test_lambda_handler(self,fixture_event):
#         ret =demo_lambda.lambda_handler(fixture_event, "")
#         data =json.loads(ret["body"])
#
#         assert ret["statusCode"] == 201
#         assert "message" in ret["body"]
#         assert data["message"] == "Registered successfully"

import unittest
from unittest.mock import MagicMock


class Testdemo(unittest.TestCase):
    def setUp(self):
        from src import demo_lambda
        self.demo_lambda = demo_lambda

    def test_check(self):
        event = {
    'plus': lambda x, y: x + y,
    'minus': lambda x, y: x - y,
    'times': lambda x, y: x * y,
    'divided-by': lambda x, y: x / y}
        event = {"name": "pooja", "surname": "agrawal"}
        expected = "Test"
        container = "Test"

        r = self.demo_lambda.lambda_handler(event, MagicMock())
        self.assertIn(expected, container, r)

    def teardown(self):
        print("success")


if __name__ == "__main__":
    unittest.main()
